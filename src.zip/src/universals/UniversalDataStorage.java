package universals;

// <editor-fold defaultstate="collapsed" desc="imports">
import gui.mainframe.componentCreator.options.FloatingPartsCounterPanel;
import gui.mainframe.componentCreator.options.IntersectionStringInputPanel;
import gui.mainframe.componentCreator.options.StrokeComplexityPanel;
import java.util.ArrayList;
import mechanics.ChineseCharacter;// </editor-fold>

/**
 *
 * @author Kieda
 */
public class UniversalDataStorage {
    public static int numberOfStrokes;
    public static int totalNumberOfIntersections;
    public static int numberOfFloatingParts;
    public static int numberOfStraightStrokes;
    public static int numberOfComplexStrokes;
    public static int getXMouseDrawing;
    public static int getYMouseDrawing;
    public static ArrayList<Integer> intersections;
    public static CreatedCharacter p = new CreatedCharacter();
    public static ChineseStroke points = new ChineseStroke();
    public static String character;
    public static String meaning;
    public static String pinyin;
    public static ChineseCharacter[]  database;
    public static void updateOptions(){
        FloatingPartsCounterPanel.setNumberOfFloatingParts(
            numberOfFloatingParts);
        IntersectionStringInputPanel.setIntersectionsString(
            intersectionsToString(intersections));
        StrokeComplexityPanel.setNumberOfComplexStrokes(numberOfComplexStrokes);
        StrokeComplexityPanel.setNumberOfStraightStrokes(
            numberOfStraightStrokes);
    }
   public static String intersectionsToString(ArrayList<Integer> intersections){
        String s = "";
        for(Integer i: intersections)
            s+=i+",";
        return s;
    }
}
