package universals;

// <editor-fold defaultstate="collapsed" desc="imports">
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;// </editor-fold>

/**
 * This class manages output to a log. This is a "static method" class so
 * LogManager does not need to be instantiated to log things
 * @version 4.2
 * @author Kieda
 * @since 3-14-2011
 */
public class LogManager {
    public static final String logsPath = "./logs/";//default path to the logs
    public static final String OLD_ERR_PATH_PRE_2_0 = "./logs/ERR.log";
        //older error log path name
    public static final String OLD_ERR_PATH_2_0 = "./logs/ERR_V2-0.log";
        //error log path for versions 2.0 to 2.8
    public static final String DEFAULT_ERR_PATH = "./logs/ERR_V3-0.log";
        //default error log path (for this version)
    public static final String DEFAULT_LOG_PATH = "./logs/LOGS_V3-0.log";
        //default log path
    public static final String DATABASE = "asd.txt";//Database path
    public static ArrayList<String> logPaths = new ArrayList<String>();
        //the String path for the file logs that are currently in use
    private static ArrayList<BufferedWriter> writers = new ArrayList<
        BufferedWriter>();
            //the BufferedWriters used to log multiple things


    /**
     * simply logs an error and the time it occurred.
     * @param e the error to log (from the catch)
     */
    public static void logError(Exception e){
        logError(e.toString()+"; "+e.getCause(),TimeManager
            .getCurrentTimeAndDate());
                //logs error
    }
    /**
     * This method logs an error, the time it occurred, the description, and the
     * place where the error happened
     * @param e the error to log (from the catch)
     * @param description the description of the error that occurred (can be user
     *        defined)
     * @param lineNumber the line number of which the error occurred
     * @param classOfException the class which called the logError
     * @param print whether or not to printStackTrace()
     */
    public static void logError(Exception e, String description, int lineNumber
            , String classOfException, boolean print){
        if(print)//if the error is to be printed
            e.printStackTrace();//print the error
        logError(e.toString()+"; "+e.getCause(),TimeManager
            .getCurrentTimeAndDate() + "; "+description + "; at line "
            +lineNumber+" of "+ classOfException);
                //compiles data to string, passes to logError(String thing
                //, String time)
    }
    /**
     * similar to logError(Exception e, String description, int lineNumber,
     * String classOfException, boolean print),
     * except this does not print anything (only logs it)
     * @param e the error to log (from the catch)
     * @param description the description of the error that occurred (can be user
     *        defined)
     * @param lineNumber the line number of which the error occurred
     * @param classOfException the class which called the logError
     */
    public static void logError(Exception e, String description, int lineNumber
            , String classOfException){
        logError(e.toString() + "; " + e.getCause(), TimeManager
            .getCurrentTimeAndDate() + "; " + description + "; at line "
            +lineNumber + " of " + classOfException);
                //compiles data to string, passes to logError(String thing,
                //String time)
    }
    /**
     * similar to logError(Exception e, String description, int lineNumber
     * , String classOfException), except that an object is used and is logged
     * @param e the error to log (from the catch)
     * @param description the description of the error that occurred (can be user
     *        defined)
     * @param lineNumber the line number of which the error occurred
     * @param classOfException the class which called the logError, in Object
     *        form
     */
    public static void logError(Exception e, String description, int lineNumber
            , Object classOfException){
        logError(e.toString( )+ "; " + e.getCause(),TimeManager
            .getCurrentTimeAndDate() + "; " + description + "; at line "
            + lineNumber + " of "+ classOfException.getClass().getSimpleName());
                //compiles data to string, passes to logError(String thing
                //, String time)
    }
    /**
     * simply logs an error and has a choice to print
     * @param e the error to log (from the catch)
     * @param print whether or not to printStackTrace()
     */
    public static void logError(Exception e, boolean print){
        if(print)//if the error is to be printed
            e.printStackTrace();//print the error
        logError(e.toString(),TimeManager.getCurrentTimeAndDate());
            //compiles error to string, passes to logError(String thing
            //, String time)
    }
    /**
     * logs something into the default log path
     * @param thing String to be logged
     */
    public static void logThing(String thing){
        logThing(thing,DEFAULT_LOG_PATH);
            //passes to logThing(String thing,String location)
    }
    /**
     * logs a string to a specific location
     * @param thing the String to be logged
     * @param location the location for the String to be logged
     */
    public static void logThing(String thing,String location, String time){
        logThing(time+"--\t"+thing,location);
            //passes to logThing(String thing, String location, String time)
    }
    /**
     * logs a String to a specific time
     * @param thing the String to be logged
     * @param time the time recorded
     */
    public static void logError(String thing, String time){
        logThing(time+"--\t"+thing,DEFAULT_ERR_PATH);
            //passes to logThing(String thing, String location, String time)
    }
    /**
     * adds a line to the end of a log. This method loads the log if it is not
     * yet loaded
     * @param thing the String to be logged
     * @param location the location for the String to be logged
     */
    public static void logThing(String thing, String location){
        try {
            if(!logPaths.contains((new File(location).getAbsolutePath()))){
                addLog(location);
            }
            for(int i = 0; i<logPaths.size();i++){
                if(logPaths.get(i).equals((new File(location).getAbsolutePath()))){
                    writers.get(i).write(thing);
                    writers.get(i).newLine();
                }
            }
        } catch (IOException ex) {/*DO NOT LOG ERRORS HERE
                                  (INFINITE LOOPS SUCK)*/}
    }
    /**
     * loads a log into the memory. The log loaded is a file, usually chosen 
     * from a final String value in this class.
     * @param s the file path of the log being added
     */
    public static void addLog(String s){
        addLog(new File(s));
            //passes to addLog(File f)
    }
    /**
     * loads a log into the memory. The log loaded is a file, usually chosen
     * from a final String value in this class.
     * @param f the file of the log being added
     */
    public static void addLog(File f){
        logPaths.add(f.getAbsolutePath());
            //for consistancy to get matching Strings, the String absolute path
            //of the loaded logs is compared to the String of the absolute path
            //of the log being wrote to.
        try {
            // <editor-fold defaultstate="collapsed" desc="initialization">
            ArrayList<String> originalLog = new ArrayList<String>();
            Scanner in = new Scanner(f);// </editor-fold>
            // <editor-fold defaultstate="collapsed" desc="loading file to be logged into memory">
            while (in.hasNext()) {
                //goes through all the previous lines in a log
                originalLog.add(in.nextLine());
                    //adds the file to be written to an ArrayList<String>
            }// </editor-fold>
            // <editor-fold defaultstate="collapsed" desc="rewriting the file">
            writers.add(new BufferedWriter(new FileWriter(f)));
                //makes a new FileWriter to create the log
                //makes a BufferedWriter to write to the log
            for (String line : originalLog) {
                //goes through all of the original lines
                writers.get(writers.size()-1).write(line);//rewrites the log
                writers.get(writers.size()-1).newLine();
                    //makes a new line for each line in ArrayList
            }
            // </editor-fold>
        } catch (FileNotFoundException ex) {}
          catch (IOException ex) {}
    }
    /**
     * closes all of the BufferedWriters writing to the logs. This method should
     * be called BEFORE THE PROGRAM EXITS, otherwise you lose ALL THE LOG DATA
     * to the logs you are writing to
     * @throws IOException exception for closing the BufferedWriters
     */
    public static void closeAllWriters() throws IOException{
        for(int i = 0; i<writers.size();i++)
                //goes through all the BufferedWriters
            writers.get(i).close();//closes the BufferedWriters
    }
}
