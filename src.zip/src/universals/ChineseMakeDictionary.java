package universals;//package

// <editor-fold defaultstate="collapsed" desc="imports">
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;// </editor-fold>

/**
 * this class was used to make the database from the copied list of the most
 * frequent Chinese characters
 * @author Kieda
 * @since forever ago
 */
public class ChineseMakeDictionary {
    static int popularity = 31;//the starting point to add characters
    static int line = 0;//the line number
    public static void main(String[] args) throws IOException {
        File loadfile = new File("lol.txt");
            //loadfile: the file with the list of the most common chinese
            //characters
        FileWriter fstream= new FileWriter("new1.txt");
            //the file being wrote to
        BufferedWriter out = new BufferedWriter(fstream);
            //the tool ues to write to the file
        Scanner in;
            //the tool used to read the loadfile
        System.out.println(loadfile.exists());
            //to check if the file exists
        while(popularity<=3000){//main loop to the 3000 most common characters
            in = new Scanner(loadfile);//makes a new scanner of the loadfile
            fast:while(in.hasNextLine()){//reads through the entire document
                String s = in.nextLine();
                if(popularity==858)//mistake in the html file
                        popularity++;//skips the line
                if(s.contains(popularity+"")){
                        //sees wether if the line inspected has the number in it
                        //(the documetnt had a format of
                        //popularity character [pinyin] UNNEEDED_STUFF
                    s = s.split(popularity+"")[1];
                        //splits up the line
                    s = s.split("]")[0];
                        //extracts the important information
                    out.write(s+"]");
                        //writes the important information and a mreak (']')
                        //which is replaces later using the Ctrl+f and replace
                        //feature
                    out.newLine();//makes a new line
                    break fast;
                        //breaks the search for a line with the popularity
                }
                line++;//the line number goes up one
            }
            popularity++;//go to the next highest popularity
            in.close();//close the scanner
        }
    }
}
