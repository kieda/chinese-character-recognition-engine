package universals;

import java.util.ArrayList;

/**
 * This class is simply made for coding purposes. Instead of calling
 * an ArrayList<Integer[]>, one can simply call a ChineseStroke.
 * @author Kieda
 * @since 3-13-2011
 */
public class ChineseStroke extends ArrayList<Integer[]>
                    {/*customized methods go in here*/}
