/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package universals;

import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import mechanics.database.DatabaseLoader;

/**
 *
 * @author Kieda
 */
public class FontFinder {
    public static Vector<String> chinesefonts;
    public static int fontcount = 0;
    public static void findFonts(){
        DatabaseLoader.j1.setText("     Finding Chinese Fonts");
        
        chinesefonts = new Vector();
	Font[] allfonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
	String chinesesample = "\u4e00";
	for (int j = 0; j < allfonts.length; j++) {
	    if (allfonts[j].canDisplayUpTo(chinesesample) == -1) {
	        chinesefonts.add(allfonts[j].getFontName());
	    }
  	    fontcount++;
	}
        try {
            Thread.sleep(500);
        } catch (InterruptedException ex) {}
        DatabaseLoader.f.dispose();
    }
}
