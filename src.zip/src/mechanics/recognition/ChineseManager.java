/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mechanics.recognition;

import java.util.ArrayList;
import universals.CreatedCharacter;

/**
 *
 * @author Kieda
 */
public interface ChineseManager<T> {
    public T returnValue();
    public T processData(CreatedCharacter p);
    public void updateManager();
}
