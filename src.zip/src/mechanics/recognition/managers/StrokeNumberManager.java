/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mechanics.recognition.managers;

import java.lang.annotation.Annotation;
import mechanics.recognition.ChineseManager;
import universals.UniversalDataStorage;
import universals.CreatedCharacter;

/**
 *
 * @author Kieda
 */
public class StrokeNumberManager implements ChineseManager<Integer>{
    public Integer returnValue() {
        return UniversalDataStorage.numberOfStrokes;
    }
    public Integer processData(CreatedCharacter p) {
        return p.size();
    }
    public void updateManager() {
        UniversalDataStorage.numberOfStrokes = processData(UniversalDataStorage.p);
    }
}
