/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mechanics.recognition.managers;

import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Arrays;
import mechanics.recognition.ChineseManager;
import universals.UniversalDataStorage;
import universals.CreatedCharacter;

/**
 * V2.0 Intersection Manager
 * @author Kieda
 */
public class IntersectionManager implements ChineseManager{
    public ArrayList<Integer>  transferArray(int[] s){
        Integer[] ai = new Integer[s.length];
        for( int d = 0; d<s.length;d++){
            ai[d] = s[d];
        }
        return new ArrayList<Integer>(Arrays.asList(ai));
    }
    @Override
    public ArrayList<Integer> processData(CreatedCharacter p) {
        ArrayList<Integer> i = new ArrayList<Integer>(p.size());
        i.ensureCapacity(p.size());
        boolean b = true;
        /*NESTED LOOPS*/
        for(int n = 0; n<p.size(); n++){
            int intersection = 0;
            ArrayList<Integer> nnn = new ArrayList<Integer>();
            for(int s = 0; s<(p.get(n).size()-1);s++){
               Line2D l1 = new Line2D.Double(p.get(n).get(s)[0], p.get(n).get(s)[1]
                            , p.get(n).get(s+1)[0] , p.get(n).get(s+1)[1]);
               for(int z = 0; z<p.size();z++){
                   if(z!=n&&!nnn.contains(z))
                       stop:for(int q = 0; q<(p.get(z).size()-1);q++){
                           Line2D l2 = new Line2D.Double(p.get(z).get(q)[0], p.get(z).get(q)[1]
                                    , p.get(z).get(q+1)[0] , p.get(z).get(q+1)[1]);
                               if(l1.intersectsLine(l2)){

                                   intersection++;
                                   nnn.add(z);
                                   break stop;
                               }
                       }

               }
            }
            i.add( intersection);
        }
        //System.out.println(Arrays.toString(i.toArray()));
        return i;
    }
    @Override
    public ArrayList<Integer> returnValue() {
        return UniversalDataStorage.intersections;
    }
    public void updateManager() {
        UniversalDataStorage.intersections = processData(UniversalDataStorage.p);
    }
}
