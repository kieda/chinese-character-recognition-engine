/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mechanics.recognition.managers;

import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import mechanics.recognition.ChineseManager;
import universals.UniversalDataStorage;
import universals.CreatedCharacter;

/**
 * @version 1.2
 * @author Kieda
 */
public class FloatingPartManager  implements ChineseManager{
    @Override
    public Integer returnValue() {
        return UniversalDataStorage.numberOfFloatingParts;
    }
    public int nextToDo(ArrayList<Integer> i, int length){
        for(int p = 0; p<length;p++){
           if(!i.contains(p))
               return p;
        }
        return -1;
    }
    public Integer processData(CreatedCharacter p) {
        ArrayList<Integer> i = new ArrayList<Integer>();
        ArrayList<Integer> zaq = new ArrayList<Integer>();
        int intersection = 0;
        /*NESTED LOOPS, ADVANCED SELECTION*/
        if(p.size()>0)
            heart:for(int n = 0;true;){
                if(!i.contains(n)){
                    i.add(n);
                    for(int s = 0; s<(p.get(n).size()-1);s++){
                       Line2D l1 = new Line2D.Double(p.get(n).get(s)[0], p.get(n).get(s)[1]
                                    , p.get(n).get(s+1)[0] , p.get(n).get(s+1)[1]);
                       for(int z = 0; z<p.size();z++){
                           if(z!=n)
                               for(int q = 0; q<(p.get(z).size()-1);q++){
                                   Line2D l2 = new Line2D.Double(p.get(z).get(q)[0], p.get(z).get(q)[1]
                                            , p.get(z).get(q+1)[0] , p.get(z).get(q+1)[1]);
                                   if(l1.intersectsLine(l2)){
                                       if(!i.contains(z)){
                                           zaq.add(z);
                                       }
                                   }
                               }
                       }
                    }
                }

                if(zaq.size()>0)
                    n = zaq.remove(zaq.size()-1);
                else{
                    n = nextToDo(i, p.size());
                    intersection++;
                }
                if(n==-1)
                    /*USE OF FLAGS*/
                    break heart;
            }
        return intersection;
    }
    public void updateManager() {
        UniversalDataStorage.numberOfFloatingParts = (processData(UniversalDataStorage.p));
    }
}
