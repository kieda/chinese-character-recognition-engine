/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mechanics.recognition.managers;

import gui.mainframe.ChineseFrame;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import mechanics.recognition.ChineseManager;
import universals.ChineseLine;
import universals.ChineseStroke;
import universals.UniversalDataStorage;
import universals.CreatedCharacter;

/**
 *
 * @author Kieda
 */
public class StrokeComplexityManager implements ChineseManager{
    
    @Override
    public Integer returnValue() {
        return UniversalDataStorage.numberOfComplexStrokes;
    }

    public void updateManager() {
        UniversalDataStorage.numberOfComplexStrokes = processData(UniversalDataStorage.p)[1];
        UniversalDataStorage.numberOfStraightStrokes = processData(UniversalDataStorage.p)[0];
    }

    public Integer[] processData(CreatedCharacter p) {
        Integer complex = 0;
        UniversalDataStorage.p = p;
        for(ArrayList<Integer[]> s: p){
            if(complexStroke((ChineseStroke) s)){
                complex++;
            }
        }
        Integer simple = p.size()-complex;
        UniversalDataStorage.numberOfComplexStrokes = complex;
        UniversalDataStorage.numberOfStraightStrokes = simple;
        return new Integer[]{simple,complex};
    }
    public boolean complexStroke(ChineseStroke p){
        boolean b = false;
        if(p.size()>=2){
            for(int i = 0; i<(p.size()-2);i++){
                ChineseLine cl1 = new ChineseLine(p.get(i)[0], p.get(i+1)[0], p.get(i+1)[1], p.get(i)[1]);
                ChineseLine cl2 = new ChineseLine(p.get(i+1)[0], p.get(i+2)[0], p.get(i+2)[1], p.get(i+1)[1]);
                if(Math.abs(cl1.totaldegrees-cl2.totaldegrees)>70&&(cl1.totaldegrees>80||cl2.totaldegrees>80)){
                    b = true;
                }
            }
        }
        return b;
    }
}
