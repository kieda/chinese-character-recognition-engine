package mechanics.database;

import universals.UniversalDataStorage;

/**
 * @version .3 shitty version :P
 * @author Kieda
 */
public class SearchEngine {
    /**
     * Searches for a character match in the database
     */
    public static void searchForChineseCharacter(){
        if(UniversalDataStorage.intersections.size()>0)
            DatabaseDriver.searchCharacter(UniversalDataStorage.intersections.toArray()
                    , UniversalDataStorage.numberOfFloatingParts
                    , UniversalDataStorage.numberOfStraightStrokes, UniversalDataStorage.numberOfComplexStrokes);
    }
}
