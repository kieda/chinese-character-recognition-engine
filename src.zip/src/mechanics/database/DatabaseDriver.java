package mechanics.database;

import gui.mainframe.componentCreator.bottompanel.PossibleChineseCharactersPanel;
import java.awt.EventQueue;
import java.io.BufferedWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import universals.LogManager;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import mechanics.ChineseCharacter;
import universals.TimeManager;
import universals.UniversalDataStorage;

/**
 * @version 1.9
 * @author Kieda
 */
public class DatabaseDriver {
    static Scanner in;
    public static ChineseCharacter searchCharacter(Object[] intersections
            ,int floatingParts,int straightStrokes,int complexStrokes){
        Integer[] intIntersections = new Integer[intersections.length];
        for(int i = 0;i<intersections.length;i++){
            intIntersections[i] = Integer.parseInt(intersections[i]+"");
        }
        return searchCharacter(intIntersections, floatingParts, straightStrokes
                , complexStrokes);
    }
    public static void addToDatabase(ChineseCharacter c){
        File f = new File("NEWEST_VERSION.data");
        try {
            ArrayList<String> originalLog = new ArrayList<String>();
            Scanner in = new Scanner(f);

            while (in.hasNext()) {
                originalLog.add(in.nextLine());//adds the file to be written to an ArrayList<String>
            }

            FileWriter bestBuddy = new FileWriter(f);
            BufferedWriter bff = new BufferedWriter(bestBuddy);
            for (String line : originalLog) {
                bff.write(line);//rewriting the log
                bff.newLine();
            }
            bff.write(c.toString());
            bff.close();
        } catch (IOException ex) {LogManager.logError(ex, "something wrong with making dictionary", 46, "DatabaseDriver", true);}
    }
    static ChineseCharacter chinesecharacter = null;
    static Integer[] intersections;
    static int floatingParts;
    static int straightStrokes;
    static int complexStrokes;
    private static boolean stop = false;
    public static ChineseCharacter searchCharacter(Integer[] intersection
            ,int floatingPart, int straightStroke, int complexStroke){
        intersections = intersection;
        floatingParts = floatingPart;
        straightStrokes = straightStroke;
        complexStrokes = complexStroke;
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                PossibleChineseCharactersPanel.clearList();
                Arrays.sort(intersections);
                no:for(ChineseCharacter c: UniversalDataStorage.database){
                    if (c.getFloatingParts() == floatingParts
                            && Arrays.toString(c.getIntersections().toArray()).equals(Arrays.toString(intersections))
                            && (c.getComplexStrokes() + c.getStraightStrokes()) == (complexStrokes + straightStrokes) //  &&straightStrokeSearch==straightStrokes
                            // &&complexStrokeSearch==complexStrokes
                            ) {
                        if(stop){
                            stop = false;
                            break no;
                        }
                        String pinyin = c.getPinyin();
                        String character = c.getCharacter();
                        String meaning = c.getMeaning();
                        chinesecharacter = new ChineseCharacter(pinyin, character, meaning, floatingParts, new ArrayList<Integer>(Arrays.asList(intersections)), straightStrokes, complexStrokes);
                        System.out.println(chinesecharacter);
                        PossibleChineseCharactersPanel.addToList(chinesecharacter);
                        LogManager.logThing("Character found:" + chinesecharacter + " " + TimeManager.getCurrentTimeAndDate());
                    }
                }
            }});
        return chinesecharacter;
    }
    public static void halt(){
        stop = true;
    }
}












/*
    EventQueue.invokeLater(new Runnable() {
            public void run() {
                PossibleChineseCharactersPanel.clearList();
                File f = new File("asd.txt");

                try {
                    in = new Scanner(f.getAbsoluteFile(), "UTF8");
                } catch (Exception bbb) {
                    in = new Scanner("");
                    LogManager.logError(bbb, "chinese data file not found", 30, "DatabaseDriver");
                }
                while (in.hasNext()) {

                    String currentLine = in.nextLine();
                    String currentLineData = currentLine.split("#")[1];
                    String[] infrormation = currentLineData.split(":");
                    String intersectionString = infrormation[1];
                    String[] intersectionsString = intersectionString.split(",");
                    //System.out.println(Arrays.toString(intersectionsString));
                    int[] intersectionSearch = new int[intersectionsString.length];
                    for (int counter = 0; counter < intersectionsString.length; counter++) {
                        //System.out.println("A");
                        intersectionSearch[counter] = Integer.parseInt(
                                intersectionsString[counter]);
                    }
                    int floatingPartSearch = Integer.parseInt(currentLineData.split(":")[0]);
                    int straightStrokeSearch = Integer.parseInt(currentLineData.split(":")[2]);
                    int complexStrokeSearch = Integer.parseInt(currentLineData.split(":")[3]);

                    Arrays.sort(intersections);
                    Arrays.sort(intersectionSearch);

                    if (floatingPartSearch == floatingParts
                            && Arrays.toString(intersectionSearch).equals(Arrays.toString(intersections))
                            && (complexStrokeSearch + straightStrokeSearch) == (complexStrokes + straightStrokes) //  &&straightStrokeSearch==straightStrokes
                            // &&complexStrokeSearch==complexStrokes
                            ) {
                        String pinyin = currentLine.split("#")[0].split(":")[0];
                        String character = currentLine.split("#")[0].split(":")[1];
                        String meaning = currentLine.split("#")[0].split(":")[2];
                        chinesecharacter = new ChineseCharacter(pinyin, character, meaning, floatingParts, new ArrayList<Integer>(Arrays.asList(intersections)), straightStrokes, complexStrokes);
                        System.out.println(chinesecharacter);
                        PossibleChineseCharactersPanel.addToList(chinesecharacter);
                        LogManager.logThing("Character found:" + chinesecharacter + " " + TimeManager.getCurrentTimeAndDate());
                    }
                }
            }
        });
}*/
