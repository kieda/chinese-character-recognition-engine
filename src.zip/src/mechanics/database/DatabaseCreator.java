/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mechanics.database;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import universals.LogManager;
import mechanics.ChineseCharacter;

/**
 * @version 1.0
 * @author Kieda
 */
public class DatabaseCreator {
    private static File loadfile = new File("new.txt");
    private static Scanner in;
     public static String next(){
        if(!done())
            return in.nextLine();
        else
            return "";
     }
     public static boolean done(){
         return !in.hasNext();
     }
     public static void init(){
         try {
             in = new Scanner(loadfile);
         } catch (IOException e) {}
     }
     public static void add(ChineseCharacter c){
         LogManager.logThing(c.toString(), LogManager.DATABASE);
     }
}
