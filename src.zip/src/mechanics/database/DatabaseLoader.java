/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mechanics.database;

import java.awt.Font;
import java.io.File;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import mechanics.ChineseCharacter;
import universals.LogManager;
import universals.UniversalDataStorage;

/**
 *
 * @author Kieda
 */
public class DatabaseLoader {
    
    static Scanner in;
    static int databaseCapacity;
    public static JFrame f;
    public static JLabel j1;
    public static void load(){
        showMessage();
        File f = new File("characters.DAT");
        try {
            in = new Scanner(f.getAbsoluteFile(), "UTF8");
        } catch (Exception bbb) {
            in = new Scanner("");
            LogManager.logError(bbb, "chinese data file not found", 30, "DatabaseDriver");
        }
        databaseCapacity = 0;
        while (in.hasNext()) {
            in.nextLine();
            databaseCapacity++;
        }
        ChineseCharacter[] data = new ChineseCharacter[databaseCapacity];
        in.close();
        try {
            in = new Scanner(f.getAbsoluteFile(), "UTF8");
        } catch (Exception bbb) {
            in = new Scanner("");
            LogManager.logError(bbb, "chinese data file not found", 30, "DatabaseDriver");
        }
        int i = 0;
        while (in.hasNext()) {
            data[i] = ChineseCharacter.toChineseCharacter(in.nextLine());
            i++;
        }
        UniversalDataStorage.database = data;
        try {
            Thread.sleep(500);
        } catch (InterruptedException ex) {}
    }
    private static void showMessage(){
        f = new JFrame("LOADING...");
        f.setResizable(false);
        j1 = new JLabel("     Loading, Please Wait");
        f.setBounds(200, 200, 400, 200);
        j1.setFont(new Font("Arial", Font.BOLD, 30));
        j1.setLocation(90, 200);
        f.add(j1);
        
        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.setVisible(true);
    }
}
