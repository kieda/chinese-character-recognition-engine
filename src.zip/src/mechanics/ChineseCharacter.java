/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mechanics;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Kieda
 */
public class ChineseCharacter {
    private String pinyin;
    private String character;
    private String meaning;
    private int   floatingParts;
    private ArrayList<Integer> intersections;
    private int   straightStrokes;
    private int   complexStrokes;

    public ChineseCharacter(String pinyin, String character, String meaning
            , int floatingParts, ArrayList<Integer> intersections, int straightStrokes
            , int complexStrokes) {
        this.character = character;
        this.pinyin = pinyin;
        this.meaning = meaning;
        this.floatingParts = floatingParts;
        this.intersections = intersections;
        this.straightStrokes = straightStrokes;
        this.complexStrokes = complexStrokes;
    }
    public String getCharacter() {
        return character;
    }
    public int getComplexStrokes() {
        return complexStrokes;
    }
    public int getFloatingParts() {
        return floatingParts;
    }
    public ArrayList<Integer> getIntersections() {
        return intersections;
    }
    public String getMeaning() {
        return meaning;
    }
    public String getPinyin() {
        return pinyin;
    }
    public int getStraightStrokes() {
        return straightStrokes;
    }
    public void setCharacter(String character) {
        this.character = character;
    }
    public void setComplexStrokes(int complexStrokes) {
        this.complexStrokes = complexStrokes;
    }
    public void setFloatingParts(int floatingParts) {
        this.floatingParts = floatingParts;
    }
    public void setIntersections(ArrayList<Integer> intersections) {
        this.intersections = intersections;
    }
    public void setMeaning(String meaning) {
        this.meaning = meaning;
    }
    public void setPinyin(String pinyin) {
        this.pinyin = pinyin;
    }
    public void setStraightStrokes(int straightStrokes) {
        this.straightStrokes = straightStrokes;
    }
    @Override
    public String toString() {
        if(this.equals(null))
            return "nuthing found";
        else{
            String intersectionsString = "";
            for(Integer i:intersections){
                intersectionsString+=(i+",");
            }
            return String.format("%s:%s:%s#%d:%s:%d:%d"
                    ,pinyin, character,meaning,floatingParts,intersectionsString
                    ,straightStrokes,complexStrokes);
        }
    }
    public static ChineseCharacter toChineseCharacter(String currentLine){
        String currentLineData = currentLine.split("#")[1];
        String[] infrormation = currentLineData.split(":");
        String intersectionString = infrormation[1];
        String[] intersectionsString = intersectionString.split(",");
        Integer[] intersections = new Integer[intersectionsString.length];
        for (int counter = 0; counter < intersectionsString.length; counter++) {
            //System.out.println("A");
            intersections[counter] = Integer.parseInt(
                    intersectionsString[counter]);
        }
        int floatingParts = Integer.parseInt(currentLineData.split(":")[0]);
        int straightStrokes = Integer.parseInt(currentLineData.split(":")[2]);
        int complexStrokes = Integer.parseInt(currentLineData.split(":")[3]);
        String pinyin = currentLine.split("#")[0].split(":")[0];
        String character = currentLine.split("#")[0].split(":")[1];
        String meaning = currentLine.split("#")[0].split(":")[2];
        Arrays.sort(intersections);
        return new ChineseCharacter(pinyin, character, meaning, floatingParts, new ArrayList<Integer>(Arrays.asList(intersections)), straightStrokes, complexStrokes);
    }
}
