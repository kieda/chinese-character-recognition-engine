/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.databaseCreatorComponents;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import sun.font.Font2D;

/**
 *
 * @author Kieda
 */
public class CharacterPanel  extends JPanel{

    public CharacterPanel(String s) {
        asd = s;
        initComponents();
    }
    private void initComponents() {
        setBorder(new LineBorder(Color.BLACK));
        setSize(100,100);
        repaint();
    }
    public String asd;
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D)g;
        BufferedImage bi = (BufferedImage) createImage(20, 20);
        Graphics2D big = bi.createGraphics();
        big.drawString(asd.split(":")[0]+"", 1, 11);
        g2d.scale(4.6, 4.6);//transformation
        g2d.drawImage(bi, 1, 1, this);
    }
    
}
