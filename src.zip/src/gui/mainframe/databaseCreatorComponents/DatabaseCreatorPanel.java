/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.databaseCreatorComponents;

import com.sun.java.swing.plaf.motif.MotifBorders.BevelBorder;
import gui.mainframe.ChineseFrameActionHandler;
import gui.mainframe.componentCreator.ChineseFrameComponent;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.LayoutStyle;
import universals.FontFinder;

/**
 * @version 1.6
 * @author Kieda
 */
public class DatabaseCreatorPanel extends JPanel implements  ChineseFrameComponent{
    private static String characterToWrite;
    private JButton addToDatabaseButton;
    private JButton clear;
    private JButton next;
    private JLabel characterToWriteLiteral;
    private JLabel characterInJPanel;
    static CharacterPanel characterPanel;
    static JLabel jl;
    public static String getCharacterToWrite() {
        return characterToWrite;
    }
    
    public static void setCharacterToWrite(String characterToWrite) {
        DatabaseCreatorPanel.characterToWrite = characterToWrite;
        if(characterToWrite.split(":")[0].length()>1)
            jl.setText(characterToWrite.split(":")[0].charAt(1)+"");
        else
            jl.setText(characterToWrite.split(":")[0].charAt(0)+"");
    }
    
    public DatabaseCreatorPanel(String characterToWrite) {
        DatabaseCreatorPanel.characterToWrite = characterToWrite;
        initComponents();
    }
    @SuppressWarnings("unchecked")
    private void initComponents() {
        jl = new JLabel();
        if(characterToWrite.split(":")[0].length()>1)
            jl.setText(characterToWrite.split(":")[0].charAt(1)+"");
        else
            jl.setText(characterToWrite.split(":")[0].charAt(0)+"");
        jl.setFont(new Font(FontFinder.chinesefonts.get(0),Font.PLAIN,70));
        setBorder(new BevelBorder(true, Color.DARK_GRAY, Color.LIGHT_GRAY));
        addToDatabaseButton = new JButton();
        clear = new JButton();
        next = new JButton();
        characterToWriteLiteral = new JLabel();
        characterInJPanel = new JLabel();

        addToDatabaseButton.setText("Add to Database");
        clear.setText("Clear");
        next.setText("Next");
        addToDatabaseButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                ChineseFrameActionHandler.addToDatabaseActionEvent(e,characterToWrite);
            }
        });
        clear.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                ChineseFrameActionHandler.clearActionPerformed(e);
            }
        });
        next.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ChineseFrameActionHandler.nextButtonActionPerformed(e);
            }
        });
        
        characterToWriteLiteral.setFont(new java.awt.Font("Tahoma", 0, 15));
        characterToWriteLiteral.setText("Character To Write");
        characterInJPanel.setText(characterToWrite);
        characterPanel = new CharacterPanel(characterToWrite);
        System.out.println(characterToWrite);

        GroupLayout layout = new GroupLayout(this);
        this.setLayout(layout);
        /*GroupLayout cpLayout = new GroupLayout(characterPanel);
        characterPanel.setLayout(cpLayout);
        cpLayout.setHorizontalGroup(
            cpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        cpLayout.setVerticalGroup(
            cpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );*/

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(characterToWriteLiteral)
                    .addComponent(jl, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                    .addGap(180)
                    .addComponent(addToDatabaseButton,50,125,200)
                    .addGap(10)
                    .addComponent(clear,50,125,200)
                
                .addContainerGap(10,Short.MAX_VALUE)
                .addComponent(next,50,125,200))
                .addGap(30)
                

        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(characterToWriteLiteral)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jl, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                
                .addContainerGap(169, Short.MAX_VALUE))
            .addGap(30)
            .addComponent(addToDatabaseButton,100,100,100)
            .addComponent(clear,100,100,100)
            .addGap(30)
            .addComponent(next,100,100,100)
        );
    }

    /*public void run() {
        while(true){
            characterPanel.repaint();
            try {
                Thread.sleep(20);
            } catch (InterruptedException ex) {}
        }
    }*/

    public Component getComponent() {
        return this;
    }
}
