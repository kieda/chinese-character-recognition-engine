/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.componentCreator.drawpanel;

import gui.mainframe.ChineseFrameActionHandler;
import gui.mainframe.componentCreator.ChineseFrameComponent;
import gui.mainframe.componentCreator.menubar.MenuBar;
import java.awt.event.KeyEvent;
import universals.LogManager;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics2D;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import javax.swing.JInternalFrame;
import mechanics.database.DatabaseDriver;
import mechanics.database.SearchEngine;
import mechanics.recognition.managers.FloatingPartManager;
import mechanics.recognition.managers.IntersectionManager;
import mechanics.recognition.managers.StrokeComplexityManager;
import mechanics.recognition.managers.StrokeNumberManager;
import universals.ChineseStroke;
import universals.CreatedCharacter;
import universals.UniversalDataStorage;

/**
 * @version 2.3
 * @author Kieda
 */
public class InternalDrawFrame extends JInternalFrame implements Runnable, MouseListener, ChineseFrameComponent{
    /*public static CreatedCharacter universalPoints = new CreatedCharacter();
    public static ChineseStroke points;*/
    
    private int positionX;
    private int positionY;
    private int frameWidth;
    private int xMouseDrawing;
    private int yMouseDrawing;
    private boolean firstTime = true;
    private static boolean dead = false;
    IntersectionManager im = new IntersectionManager();
    StrokeComplexityManager cm = new StrokeComplexityManager();
    FloatingPartManager fpm  = new FloatingPartManager();
    StrokeComplexityManager scm = new StrokeComplexityManager();
    StrokeNumberManager snm = new StrokeNumberManager();
    private InternalDrawFramePanel cp;
    BufferedImage bi;
    Graphics2D big;
    public InternalDrawFrame() {
        init();
    }
    public InternalDrawFrame(int x, int y) {
        init(x,y);
    }
    public InternalDrawFrame(int x, int y, int width) {
        init(x,y,width);
    }
    
    private void init(){
        init(0,0);
    }
    private void init(int x, int y){
        init(x,y,300);
    }
    private void init(int x, int y, int width){
        setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
        UniversalDataStorage.points = new ChineseStroke();
        positionX = x;
        positionY = y;
        frameWidth = width;
        setLocation(positionX, positionY);
        setBounds(positionX, positionY, frameWidth, frameWidth);
        addMouseListener(this);
        setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        setClosable(true);
        setMaximumSize(new java.awt.Dimension(width, width));
        setMinimumSize(new java.awt.Dimension(width, width));
        setPreferredSize(new java.awt.Dimension(width, width));
        cp = new InternalDrawFramePanel(getBounds());
        getContentPane().add(cp, BorderLayout.CENTER);
        pack();
    }
    
    public static void setUniversalPoints(CreatedCharacter points) {
        UniversalDataStorage.p = points;
    }
    public static void setPoints(ChineseStroke points) {
        UniversalDataStorage.points = points;
    }
    public static ArrayList<ArrayList<Integer[]>> getUniversalPoints() {
        return UniversalDataStorage.p;
    }
    public static ChineseStroke getPoints() {
        return UniversalDataStorage.points;
    }
    public int getXMouseDrawing() {
        return xMouseDrawing;
    }
    public int getYMouseDrawing() {
        return yMouseDrawing;
    }
    /*ITERATION*/
    public void run() {
       fast:while(true){
            pointcheck();
            UniversalDataStorage.getXMouseDrawing = getXMouseDrawing();
            UniversalDataStorage.getYMouseDrawing = getYMouseDrawing();
            repaint();
            cp.repaint();
            try{
                Thread.sleep(15);
            }
            catch(InterruptedException ex){LogManager.logError(ex,"Thread interrupted", 115, "InternalDrawFrame");}
            /*USE OF FLAGS*/
            if(dead){
                break fast;
            }
       }
        this.dispose();
    }
    
    boolean create = false;
    public void pointcheck(){
        if(create){
            /*ADVANCED SELECTION*/
            if(firstTime){
                firstTime = false;
                xMouseDrawing = getMousePosition().x;
                yMouseDrawing = getMousePosition().y;
                UniversalDataStorage.points.add(new Integer[]{xMouseDrawing-8,yMouseDrawing-27});
            }
            else{
                try {
                    if(deltaMouseMax<=Math.abs(xMouseDrawing-
                            getMousePosition().x)||deltaMouseMax<=
                            Math.abs(yMouseDrawing-getMousePosition().y)){
                    xMouseDrawing = getMousePosition().x;
                    yMouseDrawing = getMousePosition().y;
                    UniversalDataStorage.points.add(new Integer[]{xMouseDrawing-8,yMouseDrawing-27});
                }
                } catch (Exception e) {LogManager.logError(e,"mouse goes off drawpanel", 144, "InternalDrawFrame");}
                
            }
        }
    }
    public void mousePressed(MouseEvent e) {
        DatabaseDriver.halt();
        create = true;
        pointcheck();
        
    }
    public void mouseClicked(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {
        if(MenuBar.getPenOrEraser())
            UniversalDataStorage.p.add(UniversalDataStorage.points);
        else
            UniversalDataStorage.p.erase(UniversalDataStorage.points);
        UniversalDataStorage.numberOfStrokes = snm.processData(UniversalDataStorage.p);
        UniversalDataStorage.intersections = im.processData(UniversalDataStorage.p);
        UniversalDataStorage.numberOfComplexStrokes = cm.processData(UniversalDataStorage.p)[1];
        UniversalDataStorage.numberOfStraightStrokes = cm.processData(UniversalDataStorage.p)[0];
        UniversalDataStorage.numberOfFloatingParts = fpm.processData(UniversalDataStorage.p);
        System.out.printf("Intersections %s; Complex %d; Simple %d; Floating %d; Stroke Count %d\n"
                , Arrays.toString(UniversalDataStorage.intersections.toArray())
                , UniversalDataStorage.numberOfComplexStrokes
                , UniversalDataStorage.numberOfStraightStrokes
                , UniversalDataStorage.numberOfFloatingParts
                , UniversalDataStorage.numberOfStrokes
                );
        SearchEngine.searchForChineseCharacter();
        create = false;
        UniversalDataStorage.points = new ChineseStroke();
        UniversalDataStorage.updateOptions();
    }
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public Component getComponent() {
        return(this);
    }
    public static void kill(){
        dead = true;
    }
}
