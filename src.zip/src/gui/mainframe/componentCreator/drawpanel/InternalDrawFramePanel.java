/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.componentCreator.drawpanel;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import universals.ChineseStroke;
import universals.UniversalDataStorage;

/**
 *
 * @author Kieda
 */
public class InternalDrawFramePanel extends JPanel{
    public InternalDrawFramePanel(Rectangle bounds) {
        setBounds(bounds);
    }
    private BufferedImage bi;
    private Graphics2D big;
    static boolean firstTime = true;
    @Override
    public void paintComponent(Graphics g){
        ChineseStroke points = InternalDrawFrame.getPoints();
        Graphics2D g2= (Graphics2D) g;
        if(firstTime){
            Dimension dim = getSize();
            bi = (BufferedImage) createImage(dim.width, dim.height);
            big = (Graphics2D) bi.createGraphics();
            big.clearRect(0, 0, bi.getWidth(), bi.getHeight());
            big.setStroke(new BasicStroke(3, BasicStroke.CAP_SQUARE, BasicStroke
                    .JOIN_ROUND, 1.0f, new float[] {10,10,10,10,10}, 0));
            big.setPaint(Color.LIGHT_GRAY);
            big.drawLine(0, dim.height/2, dim.width, dim.height/2);
            big.drawLine(dim.width/2, 0, dim.width/2, dim.height);
            big.setStroke(new BasicStroke(1));
            big.setPaint(Color.BLACK);
            firstTime = false;
        }
        if(points.size()>1){
            for(int i = 1; i<points.size();i++){
               big.setPaint(Color.BLACK);
               big.drawLine(points.get(i-1)[0], points.get(i-1)[1]
                            , points.get(i)[0] , points.get(i)[1]);
               big.setPaint(Color.GRAY);
               big.drawOval(points.get(i-1)[0]-1, points.get(i-1)[1]-1, 2, 2);
            }
        }
        g2.drawImage(bi, 0, 0, this);
    }
    public static void clearPanel(){
        firstTime = true;
        UniversalDataStorage.p.clear();
        UniversalDataStorage.points.clear();
    }
}
