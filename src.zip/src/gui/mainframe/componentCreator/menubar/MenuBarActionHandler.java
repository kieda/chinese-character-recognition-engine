/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.componentCreator.menubar;

import drivers.FinderMain;
import gui.mainframe.ChineseFrameActionHandler;
import gui.mainframe.componentCreator.drawpanel.InternalDrawFramePanel;
import java.awt.event.ActionEvent;

/**
 *
 * @author Kieda
 */
public class MenuBarActionHandler extends MenuBar{
    public static boolean penOrEraser = true;
    public static void exitActionPerformed(ActionEvent evt) {
        ChineseFrameActionHandler.exitMenuButtonActionPerformed(evt);
    }
    public static void clearActionPerformed(ActionEvent evt) {
        InternalDrawFramePanel.clearPanel();
    }
    public static void penStateChanged(ActionEvent evt) {
        MenuBar.penOrEraser(penOrEraser);
    }
    public static void eraserStateChanged(ActionEvent evt) {
        penOrEraser = false;
        MenuBar.penOrEraser(!penOrEraser);
        
    }
}
