/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.componentCreator.menubar;

import gui.mainframe.componentCreator.ChineseFrameComponent;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;

/**
 *
 * @author Kieda
 */
public class MenuBar extends JMenuBar implements ChineseFrameComponent {
    private static JMenu edit = new JMenu();
    private static JMenuItem exitMenuButton = new JMenuItem();
    private static JMenuItem clear = new JMenuItem();
    private static JMenu file = new JMenu();
    private static JMenu chineseCharacterFinder = new JMenu();
    private static JRadioButtonMenuItem eraser = new JRadioButtonMenuItem();
    private static JRadioButtonMenuItem pen = new JRadioButtonMenuItem();
    private static JRadioButtonMenuItem addToDatabase = new JRadioButtonMenuItem();
    private static JMenuItem newCharacterMenuButton = new JMenuItem();
    public MenuBar() {
        file.setText("File");
        exitMenuButton.setText("Exit");
        clear.setText("Clear");
        exitMenuButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                MenuBarActionHandler.exitActionPerformed(evt);
            }
        });
        clear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MenuBarActionHandler.clearActionPerformed(e);
            }
        });
        file.add(exitMenuButton);

        newCharacterMenuButton.setText("New Character");
        //file.add(newCharacterMenuButton);

        add(file);

        edit.setText("Edit");
        edit.add(clear);
        eraser.setSelected(false);
        eraser.setText("Eraser");
        eraser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MenuBarActionHandler.eraserStateChanged(e);
            }
        });
        //edit.add(eraser);
        pen.setSelected(true);
        pen.setText("Pen");
        pen.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MenuBarActionHandler.penStateChanged(e);
            }
        });
        //edit.add(pen);

        add(edit);
        chineseCharacterFinder.setText("Chinese Character Finder");
        add(chineseCharacterFinder);
    }
    @Override
    public Component getComponent() {
        return this;
    }
    public static void penOrEraser(boolean b){
        eraser.setSelected(b);
        pen.setSelected(!b);
    }
    public static boolean getPenOrEraser(){
        return pen.isSelected();
    }

}
