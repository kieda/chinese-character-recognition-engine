package gui.mainframe.componentCreator.bottompanel;//package

import gui.mainframe.componentCreator.ChineseFrameComponent;
import gui.mainframe.componentCreator.drawpanel.InternalDrawFramePanel;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.AbstractListModel;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle;
import mechanics.ChineseCharacter;
import universals.FontFinder;

/**
 * This is another component implementing ChineseFrameComponent
 * @author Kieda
 * @since 3-13-2011
 */
public class PossibleChineseCharactersPanel extends JPanel implements
        ChineseFrameComponent, MouseListener{
    private static JLabel possibleChineseCharactersLabel = new JLabel();
    private static JList listOfPossibleChineseCharacters = new JList();
    private static JScrollPane JSP;
    static ArrayList<String> strings = new ArrayList<String>();
    public PossibleChineseCharactersPanel() {
        listOfPossibleChineseCharacters.setFont(new Font(FontFinder.chinesefonts.get(0),Font.PLAIN,14));
        setBorder(BorderFactory.createEtchedBorder());
        possibleChineseCharactersLabel.setText("Possible Chinese Characters");
        listOfPossibleChineseCharacters.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
        listOfPossibleChineseCharacters.addMouseListener(this);
        listOfPossibleChineseCharacters.setModel(new AbstractListModel() {
            String[] strings = {""};
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        JSP = new JScrollPane(listOfPossibleChineseCharacters);
        GroupLayout possibleChineseCharactersPanelLayout = new GroupLayout(this);
        setLayout(possibleChineseCharactersPanelLayout);
        possibleChineseCharactersPanelLayout.setHorizontalGroup(
            possibleChineseCharactersPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(possibleChineseCharactersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(possibleChineseCharactersPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(possibleChineseCharactersPanelLayout.createSequentialGroup()
                        .addComponent(JSP, GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(possibleChineseCharactersPanelLayout.createSequentialGroup()
                        .addComponent(possibleChineseCharactersLabel)
                        .addGap(89, 89, 89))))
        );
        possibleChineseCharactersPanelLayout.setVerticalGroup(
            possibleChineseCharactersPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(possibleChineseCharactersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(possibleChineseCharactersLabel)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JSP, GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE)
                .addContainerGap())
        );
    }
    
    public static void addToList(ChineseCharacter c){
        
        strings.add(c.toString());
        listOfPossibleChineseCharacters.setModel(new AbstractListModel() {
            public int getSize() { return strings.size(); }
            public Object getElementAt(int i) { return strings.get(i); }
        });
    }
    public static void clearList(){
        strings = new ArrayList<String>();
        listOfPossibleChineseCharacters.setModel(new AbstractListModel() {
            public int getSize() { return strings.size(); }
            public Object getElementAt(int i) { return strings.get(i); }
        });
    }
    public Component getComponent() {
        return this;
    }
    public void mouseClicked(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
        String s = (((String) listOfPossibleChineseCharacters.getSelectedValue()).split(":")[0]);
            if(s.length() >1)
                s = s.charAt(1)+"";
            CharacterFieldPanel.addToList(s);
            InternalDrawFramePanel.clearPanel();
    }
    public void mouseReleased(MouseEvent e) {
    }
    public void mouseEntered(MouseEvent e) {
    }
    public void mouseExited(MouseEvent e) {
    }
}
