/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.componentCreator.options;

import gui.mainframe.ChineseFrameActionHandler;
import gui.mainframe.componentCreator.ChineseFrameComponent;
import java.awt.Color;
import java.awt.Component;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

/**
 *
 * @author Kieda
 */
public class IntersectionStringInputPanel extends JPanel implements ChineseFrameComponent{
    private static JTextField intersectionsStringInput = new JTextField();
    private static JLabel intersectionsStringInputLabel = new JLabel();
    public IntersectionStringInputPanel() {
        setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));

        intersectionsStringInput.addCaretListener(new CaretListener() {
            public void caretUpdate(CaretEvent evt) {
                ChineseFrameActionHandler.intersectionsStringInputCaretUpdate(evt);
            }
        });

        intersectionsStringInputLabel.setText("String Input (separate by commas)");

        GroupLayout intersectionsStringInputPanelLayout = new GroupLayout(this);
        setLayout(intersectionsStringInputPanelLayout);
        intersectionsStringInputPanelLayout.setHorizontalGroup(
            intersectionsStringInputPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(intersectionsStringInputPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(intersectionsStringInputPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(intersectionsStringInputPanelLayout.createSequentialGroup()
                        .addComponent(intersectionsStringInput, GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(GroupLayout.Alignment.TRAILING, intersectionsStringInputPanelLayout.createSequentialGroup()
                        .addComponent(intersectionsStringInputLabel)
                        .addGap(25, 25, 25))))
        );
        intersectionsStringInputPanelLayout.setVerticalGroup(
            intersectionsStringInputPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, intersectionsStringInputPanelLayout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(intersectionsStringInputLabel)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(intersectionsStringInput, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }
    public static String getIntersectionsString() {
        return intersectionsStringInput.getText();
    }
    public static void setIntersectionsString(String s) {
        intersectionsStringInput.setText(s);
    }
    public Component getComponent() {
        return this;
    }

}
