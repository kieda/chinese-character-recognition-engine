/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.componentCreator.options;

import gui.mainframe.ChineseFrameActionHandler;
import gui.mainframe.componentCreator.ChineseFrameComponent;
import java.awt.Color;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.LayoutStyle;

/**
 *
 * @author Kieda
 */
public class FloatingPartsCounterPanel extends JPanel implements ChineseFrameComponent{
    private static JSpinner numberOfFloatingPartsCounter = new JSpinner();
    private static JLabel numberOfFloatingPartsLabel = new JLabel();
    public FloatingPartsCounterPanel() {
        setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));

        numberOfFloatingPartsLabel.setText("Number of Floating Parts");

        numberOfFloatingPartsCounter.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
                ChineseFrameActionHandler.numberOfFloatingPartsCounterPropertyChange(evt);
            }
        });

        GroupLayout numberOfFloatingPartsPanelLayout = new GroupLayout(this);
        setLayout(numberOfFloatingPartsPanelLayout);
        numberOfFloatingPartsPanelLayout.setHorizontalGroup(
            numberOfFloatingPartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, numberOfFloatingPartsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(numberOfFloatingPartsCounter, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(numberOfFloatingPartsLabel)
                .addContainerGap())
        );
        numberOfFloatingPartsPanelLayout.setVerticalGroup(
            numberOfFloatingPartsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(numberOfFloatingPartsPanelLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(numberOfFloatingPartsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(numberOfFloatingPartsLabel)
                    .addComponent(numberOfFloatingPartsCounter, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
    }
    public static int getNumberOfFloatingParts() {
        return Integer.parseInt(numberOfFloatingPartsCounter.getValue()+"");
    }
    public static void setNumberOfFloatingParts(int i) {
        numberOfFloatingPartsCounter.setValue(i);
    }
    public Component getComponent() {
        return this;
    }

}
