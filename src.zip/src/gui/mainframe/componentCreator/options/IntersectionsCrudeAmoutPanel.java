/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.componentCreator.options;

import gui.mainframe.ChineseFrameActionHandler;
import gui.mainframe.componentCreator.ChineseFrameComponent;
import java.awt.Color;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.LayoutStyle;

/**
 *
 * @author Kieda
 */
public class IntersectionsCrudeAmoutPanel extends JPanel implements ChineseFrameComponent{
    private static JSpinner totalNumberOfIntersectionsCounter = new JSpinner();
    private static JLabel totalNumberOfIntersectionsLabel = new JLabel();
    public IntersectionsCrudeAmoutPanel() {
        setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));

        totalNumberOfIntersectionsLabel.setText("Total Number of Intersections");

        totalNumberOfIntersectionsCounter.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
                ChineseFrameActionHandler.totalNumberOfIntersectionsCounterPropertyChange(evt);
            }
        });

        GroupLayout totalNumberOfIntersectionsPanelLayout = new GroupLayout(this);
        setLayout(totalNumberOfIntersectionsPanelLayout);
        totalNumberOfIntersectionsPanelLayout.setHorizontalGroup(
            totalNumberOfIntersectionsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, totalNumberOfIntersectionsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(totalNumberOfIntersectionsCounter, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(totalNumberOfIntersectionsLabel)
                .addContainerGap())
        );
        totalNumberOfIntersectionsPanelLayout.setVerticalGroup(
            totalNumberOfIntersectionsPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(totalNumberOfIntersectionsPanelLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(totalNumberOfIntersectionsPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(totalNumberOfIntersectionsLabel)
                    .addComponent(totalNumberOfIntersectionsCounter, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
    }
    public static int getTotalNumberOfIntersections() {
        return Integer.parseInt(totalNumberOfIntersectionsCounter.getValue()+"");
    }
    public static void setTotalNumberOfIntersections(int i) {
        totalNumberOfIntersectionsCounter.setValue(i);
    }
    public Component getComponent() {
        return this;
    }

}
