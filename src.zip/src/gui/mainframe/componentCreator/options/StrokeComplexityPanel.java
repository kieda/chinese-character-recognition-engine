/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.mainframe.componentCreator.options;

import gui.mainframe.ChineseFrameActionHandler;
import gui.mainframe.componentCreator.ChineseFrameComponent;
import java.awt.Color;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.LayoutStyle;

/**
 *
 * @author Kieda
 */
public class StrokeComplexityPanel extends JPanel implements ChineseFrameComponent{
    private static JSpinner numberOfStraightStrokesCounter = new JSpinner();
    private static JLabel numberOfStraightStrokesLabel = new JLabel();
    private static JLabel numberOfComplexStrokesLabel= new JLabel();
    private static JSpinner numberOfComplexStrokesCounter = new JSpinner();
    public StrokeComplexityPanel() {
        setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));

        numberOfStraightStrokesLabel.setText("Number of Straight Strokes");

        numberOfStraightStrokesCounter.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
                ChineseFrameActionHandler.numberOfStraightStrokesCounterPropertyChange(evt);
            }
        });

        numberOfComplexStrokesLabel.setText("Number of Complex Strokes");

        numberOfComplexStrokesCounter.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
                ChineseFrameActionHandler.numberOfComplexStrokesCounterPropertyChange(evt);
            }
        });

        GroupLayout strokeComplexityPanelLayout = new GroupLayout(this);
        setLayout(strokeComplexityPanelLayout);
        strokeComplexityPanelLayout.setHorizontalGroup(
            strokeComplexityPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(strokeComplexityPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(strokeComplexityPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
                    .addComponent(numberOfComplexStrokesCounter, GroupLayout.Alignment.TRAILING)
                    .addComponent(numberOfStraightStrokesCounter, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(strokeComplexityPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(numberOfStraightStrokesLabel, GroupLayout.Alignment.TRAILING)
                    .addComponent(numberOfComplexStrokesLabel, GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        strokeComplexityPanelLayout.setVerticalGroup(
            strokeComplexityPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(strokeComplexityPanelLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(strokeComplexityPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(numberOfStraightStrokesLabel)
                    .addComponent(numberOfStraightStrokesCounter, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(strokeComplexityPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(numberOfComplexStrokesLabel)
                    .addComponent(numberOfComplexStrokesCounter, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
    }
    public static int getNumberOfStraightStrokes() {
        return Integer.parseInt(numberOfStraightStrokesCounter.getValue()+"");
    }
    public static int getNumberOfComplexStrokes() {
        return Integer.parseInt(numberOfComplexStrokesCounter.getValue()+"");
    }
    public static void setNumberOfStraightStrokes(int i) {
        numberOfStraightStrokesCounter.setValue(i);
    }
    public static void setNumberOfComplexStrokes(int i) {
        numberOfComplexStrokesCounter.setValue(i);
    }
    public Component getComponent() {
        return this;
    }

}
