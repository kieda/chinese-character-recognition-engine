
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author zk163427
 */
public class Stroke {
public ArrayList<Integer> parts;
public ArrayList<Integer[]> intersections;
final int X = 0;
final int Y = 1;
}
