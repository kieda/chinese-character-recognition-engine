/**
 * @since 19 Nov. 2010
 * @author Ubiquin0ne
 * The main class: where the program starts.
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Runnable r = new Core();
        Thread t = new Thread(r);
        t.start();
    }
}
