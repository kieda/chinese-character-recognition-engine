
import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author zk163427
 */
public class Character {
public int stroke_number;
public ArrayList<Stroke> strokes;
}
