
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @since 18 Nov. 2010
 * @author Ubiquin0ne
 * This is the core. It is the main
 * class for running the program
 */
public class Core implements Runnable{
    ScreenManager sm;
    final static int X = 0;
    final static int Y = 1;
    static ArrayList<Double[]> points = new ArrayList<Double[]>();
    static ArrayList<ArrayList<Double[]>> strokeListCoordinants = new ArrayList<ArrayList<Double[]>>();
    public Core() {
        sm = new ScreenManager();
    }
    public static void addPoint(double xPoint, double yPoint) {
        Double pointArray[] = {xPoint, yPoint};
        points.add(pointArray);
    }
    public void run() {
        while(true) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(Core.class.getName()).log(Level.SEVERE, null, ex);
            }
            sm.repaint();
        }
    }
}
