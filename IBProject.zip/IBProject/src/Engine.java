
import java.util.ArrayList;

/**
 * @since 19 Nov. 2010
 * @author Ubiquin0ne
 * This is the Engine. It is the "Engine"
 * for finding and identifying characters
 */
public class Engine {
    final static int X = 0;
    final static int Y = 1;
    // <editor-fold defaultstate="collapsed" desc="Character Identification">
    //IDENTIFICATION OF A CHARACTER BY...********************************************
    /**stroke number*/
    static int numOfStrokes = 0;
    /**radical number*/
    static int numOfRadicals = 0;
    /**touching strokes*/
    static ArrayList<Integer> touchingStrokes = new ArrayList<Integer>();
    /**intersecting strokes*/
    static ArrayList<Integer> intersectingStrokes = new ArrayList<Integer>();
    /**list of strokes*/
    static ArrayList<Integer> strokeList = new ArrayList<Integer>();// </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="Strokes">
    //BASIC STROKES******************************************************************
    /**Tiny Dash*/
    public final static int DIAN = 0;
    /**Horizontal Stroke*/
    public final static int HENG = 1;
    /**Vertical Stroke*/
    public final static int SHU = 2;
    /**Flick Up and Rightwards*/
    public final static int TI = 3;
    /**Falling Rightwards (flattening at bottom)*/
    public final static int NA = 4;
    /**Falling Leftwards (with slight curve)*/
    public final static int PIE = 5;
    //COMBINING STROKES**************************************************************
    /**A 90 degree turn*/
    public final static int ZHE = 6;
    /**Hook*/
    public final static int GOU = 7;
    /**Bent Concave on Left*/
    public final static int WAN = 8;
    /**Slant Concave on Right*/
    public final static int XIE = 9;// </editor-fold>
    /**
     *
     */
    public Engine() {
        
    }
    public static void constructStroke(ArrayList<Double[]> points)
    {
        Stroke s = new Stroke();
        for(int c = 0; c<points.size(); c++ )
        {
            if((c>=1&&c<(points.size()-1))&&((points.get(c-1)[X]!=points.get(c)[X])&&(points.get(c-1)[Y]!=points.get(c)[Y])))
            {
                if(Math.abs(Math.toDegrees(theta(points.get(c-1)[X],points.get(c-1)[Y],points.get(c)[X],points.get(c)[Y]))
                    -Math.toDegrees(theta(points.get(c)[X],points.get(c)[Y],points.get(c+1)[X],points.get(c+1)[Y])))>90)
                {
                        System.out.println("lool");
                }
            }
        }
        System.out.println();
        //return s;
    }
    public double derivativeLine(double x1,double y1,double x2,double y2)
    {
        return (double)(x2-x1)/(y2-y1);
    }
    public static double theta(double x1,double y1,double x2,double y2)
    {
        return Math.atan((y2-y1)/(x2-x1));
    }

}
