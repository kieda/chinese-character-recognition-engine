
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JToolBar;
import sun.swing.WindowsPlacesBar;

/**
 * @since 19 Nov. 2010
 * @author Ubiquin0ne
 * The ScreenManager deals with displaying the program and user I/O
 */
public class ScreenManager extends JFrame implements KeyListener, MouseListener{

    CustomizedButton clear_screen_button;
    CustomizedButton close_button;
    CustomizedButton simple_dialog_button;
    BufferedImage bi;
    Graphics2D big;
    Graphics2D gCurr;
    Graphics2D g2d;
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    
    boolean isMouseDown = false;
    private boolean firstTime = true;
    public ScreenManager() {
        setLayout(null);
        setBounds(0, 0, d.height-40, d.height-40);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //JToolBar jtb = new JToolBar("OPTIONS", JToolBar.HORIZONTAL);
        addKeyListener(this);
        addMouseListener(this);
    }//End of constructor
    @Override
    public void paint(Graphics g){
        update(g);
    }//End of paint
    @Override
    public void update(Graphics g){
        if(firstTime) {
            bi = (BufferedImage) createImage(getWidth(), getHeight());
            big = bi.createGraphics();
            Stroke s = new BasicStroke(10.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
            big.setStroke(s);
            firstTime = false;
        }
        g2d = (Graphics2D)g;
        if(isMouseDown){
            try{Core.addPoint(getMousePosition().x, getMousePosition().y);}
            catch(Exception e){}
        }

        clear_screen_button  = new CustomizedButton(0,  40, 150, 120, "CLEAR", Color.lightGray);
        simple_dialog_button = new CustomizedButton(0, 130, 150, 210, "SIMPLE FIND", Color.lightGray);
        close_button         = new CustomizedButton(0, 220, 150, 300, "CLOSE", Color.lightGray);


        
        for(int p = 1; p< Core.points.size();p++){
            big.setColor(Color.BLACK);
            big.drawLine((int)(Core.points.get(p)[Core.X].doubleValue())
                    , (int)(Core.points.get(p)[Core.Y].doubleValue())
                    , (int)(Core.points.get(p-1)[Core.X].doubleValue())
                    , (int)(Core.points.get(p-1)[Core.Y].doubleValue()));
        }

        big.drawImage(clear_screen_button.getButton() , null, clear_screen_button.x1 , clear_screen_button.y1 );
        big.drawImage(simple_dialog_button.getButton(), null, simple_dialog_button.x1, simple_dialog_button.y1);
        big.drawImage(close_button.getButton(), null  , close_button.x1              , close_button.y1        );
        
        String str = Engine.numOfStrokes+"";
        big.clearRect(500, 500-12, str.length()*12, 12);
        big.drawString(Engine.numOfStrokes+"", 500, 500);
        g2d.drawImage(bi, 0, 0, this);
    }//End of update
    public void keyTyped(KeyEvent e) {
    }//End of keyTyped
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_F5:
                Core.strokeListCoordinants.clear();
                Engine.numOfStrokes = 0;
                firstTime = true;
                Core.points.clear();break;
        }
    }//End of keyPressed
    public void keyReleased(KeyEvent e) {
    }//End of keyReleased
    public void mouseClicked(MouseEvent e) {
    }//End of mouseClicked
    public void mousePressed(MouseEvent e) {
        if(clear_screen_button.getBounds().contains(e.getPoint())
                ||close_button.getBounds().contains(e.getPoint())
                ||simple_dialog_button.getBounds().contains(e.getPoint())){
        
            if(clear_screen_button.getBounds().contains(e.getPoint())){
                Core.strokeListCoordinants.clear();
                firstTime = true;
                Core.points.clear();
                clear_screen_button.backgroundColor = Color.RED;
                clear_screen_button.big.setPaint(Color.RED);
                Engine.numOfStrokes = -1;
                repaint();
            }
            if(close_button.getBounds().contains(e.getPoint())){
                System.exit(0);
            }
            if(simple_dialog_button.getBounds().contains(e.getPoint())){}
        }
        else
            isMouseDown = true;
    }//End of mousePressed
    public void mouseReleased(MouseEvent e) {
        Core.strokeListCoordinants.add(Core.points);
        Engine.constructStroke(Core.points);
        Engine.numOfStrokes = Core.strokeListCoordinants.size();
        Core.points.clear();
        isMouseDown = false;
        gCurr = g2d;
    }//End of mouseReleased
    public void mouseEntered(MouseEvent e) {
    }//End of mouseEntered
    public void mouseExited(MouseEvent e) {
    }//End of mouseExited
}//End of class ScreenManager
