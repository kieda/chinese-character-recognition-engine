
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

/**
 * @since 19 Nov. 2010
 * @author Ubiquin0ne
 * This is the CustomizedButton class. It creates
 * a button in java AWT for an AWT environment
 */
public class CustomizedButton {
    int x1;
    int y1;
    int x2;
    int y2;
    String message;
    Color originalColor;
    Color backgroundColor;
    Graphics2D big;
    public CustomizedButton(int x1, int y1, int x2, int y2, String message, Color backgroundColor) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.message = message;
        this.backgroundColor = backgroundColor;
        originalColor = backgroundColor;
    }
    public BufferedImage getButton(){
        BufferedImage bi = new BufferedImage(Math.abs(x1-x2), Math.abs(y1-y2), BufferedImage.TYPE_INT_RGB);
        big = bi.createGraphics();
        big.setPaint(backgroundColor);
        big.fillRect(0, 0, Math.abs(x1-x2), Math.abs(y1-y2));
        big.setPaint(Color.BLACK);
        big.setFont(new Font("Arial", Font.PLAIN, 30));
        big.drawString(message, 10,70);
        big.setPaint(Color.BLUE);
        Stroke s = new BasicStroke(10.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        big.setStroke(s);
        big.drawRect(0, 0, Math.abs(x1-x2), Math.abs(y1-y2));
        return bi;
    }
    public Rectangle2D getBounds() {
        return new Rectangle2D.Double(x1, y1, Math.abs(x1-x2), Math.abs(y1-y2));
    }
    public void isTouched(boolean touched) {

        if(touched){
            backgroundColor = Color.RED;
        }
        //else
            //backgroundColor = originalColor;
    }
}
